//
//  LFTabView.m
//  多行标签
//
//  Created by 高立发 on 2016/12/22.
//  Copyright © 2016年 GG. All rights reserved.
//

#define kTitleFont [UIFont systemFontOfSize:16.0]
#define kExtraW 20

#import "LFTabView.h"

@interface LFTabView()

//**  titleArray */
@property (nonatomic, strong) NSArray *titleArray;

//**  存放index值的数组 */
@property (nonatomic, strong) NSMutableArray *indexArr;
//**  存放标题的数组 */
@property (nonatomic, strong) NSMutableArray *titlesArr;

//**  记录所需高度 */
@property (nonatomic, assign) CGFloat maxH;

@end

@implementation LFTabView

#pragma mark - init
/// 创建view的构造方法
- (instancetype)initWithTitleArray:(NSArray *)titleArray
                       countPerRow:(NSUInteger)countPerRow
                           marginV:(CGFloat)marginV
                           marginH:(CGFloat)marginH
                       normalColor:(UIColor *)normalColor
                     selectedColor:(UIColor *)selectedColor
                              TabH:(CGFloat)tabH
                         edgeInset:(UIEdgeInsets)edgeInset
{
    self = [super init];
    if (!self) {
        return nil;
    }
    self.backgroundColor = [UIColor whiteColor];
    _titleArray    =  titleArray;
    _countPerRow   =  countPerRow   ?  countPerRow   :  3;
    _marginV       =  marginV       ?  marginV       :  10;
    _marginH       =  marginH       ?  marginH       :  10;
    _normalColor   =  normalColor   ?  normalColor   :  [UIColor whiteColor];
    _selectedColor =  selectedColor ?  selectedColor :  [UIColor orangeColor];
    _tabH          =  tabH          ?  tabH          :  40;
    _edgeInset     =  edgeInset;
    
    return self;
}

#pragma mark - lazy
- (UIScrollView *)scrollView
{
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc]init];
        _scrollView.showsVerticalScrollIndicator = NO;
        _scrollView.showsHorizontalScrollIndicator = NO;
    }
    return _scrollView;
}

- (NSMutableArray *)titlesArr
{
    if (!_titlesArr) {
        _titlesArr = [[NSMutableArray alloc]init];
    }
    return _titlesArr;
}

- (NSMutableArray *)indexArr
{
    if (!_indexArr) {
        _indexArr = [[NSMutableArray alloc]init];
    }
    return _indexArr;
}

#pragma mark - set
- (void)setFrame:(CGRect)frame
{
    [super setFrame:frame];
    self.scrollView.frame = CGRectMake(0, 0, frame.size.width, frame.size.height);
    [self creatTab];
}

- (void)setBackgroundColor:(UIColor *)backgroundColor
{
    [super setBackgroundColor:backgroundColor];
    self.scrollView.backgroundColor = backgroundColor;
}

/**
      现在这所有的标签都是等宽的,没有考虑根据文字的多少自定义宽度
 */
- (void)creatTab
{
    CGFloat kViewW = self.frame.size.width;
    [self addSubview:self.scrollView];
    
    // 公式: (view宽度 - 中间的所有间距 - 左右间距) = 每行所有标签的总宽度 / 每行标签个数
    CGFloat bH = _tabH;
    CGFloat bX = _edgeInset.left;
    CGFloat bY = _edgeInset.top;
    for (NSUInteger i = 0; i < _titleArray.count; i++) {
        
        CGFloat bW = [_titleArray[i] boundingRectWithSize:CGSizeMake(kViewW, _tabH)
                                                 options:NSStringDrawingUsesLineFragmentOrigin
                                              attributes:@{NSFontAttributeName : kTitleFont}
                                                 context:nil].size.width + kExtraW;
        
        if (bX + bW > kViewW) {
            bX = _edgeInset.left;
            bY = bY + _tabH + _marginV;
        }
        
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.tag = 100+i;
        btn.layer.cornerRadius = 3.0f;
        btn.clipsToBounds = YES;
        btn.layer.borderColor = [UIColor lightGrayColor].CGColor;
        btn.layer.borderWidth = 0.5f;
        btn.frame = CGRectMake(bX, bY, bW, bH);
        btn.selected = NO;
        [btn setTitle:_titleArray[i] forState:UIControlStateNormal];
        [btn setBackgroundColor:_normalColor];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(bClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.scrollView addSubview:btn];
        
        _maxH = CGRectGetMaxY(btn.frame);
        
        bX = CGRectGetMaxX(btn.frame) + _marginH;
        bY = btn.frame.origin.y;
        
        if (bX > kViewW) {
            bX = _edgeInset.left;
            bY = CGRectGetMaxY(btn.frame) + _marginV;
        }
    }
    self.scrollView.contentSize = CGSizeMake(kViewW, _maxH + _edgeInset.bottom);
}

#pragma mark - Action
- (void)bClick:(UIButton *)currentB
{
    currentB.selected = !currentB.isSelected;
    
    __weak LFTabView *weakSelf = self;
    
    [currentB setBackgroundColor:currentB.isSelected ? _selectedColor : _normalColor];
    
    if (currentB.isSelected) {
        [self.indexArr addObject:@(currentB.tag - 100)];
        [self.titlesArr addObject:currentB.titleLabel.text];
    } else {
        [self.indexArr removeObject:@(currentB.tag - 100)];
        [self.titlesArr removeObject:currentB.titleLabel.text];
    }
    
    // block
    if (_tabClick) {
        _tabClick(weakSelf.indexArr, weakSelf.titlesArr);
    }
    
    // delegate
    if ([self.delegate respondsToSelector:@selector(didSelectATabAtIndex:titleStr:)]) {
        [self.delegate didSelectATabAtIndex:self.indexArr titleStr:self.titlesArr];
    }
}


// 返回一个创建这些标签所需的高度
- (CGFloat) requiredH
{
    CGFloat bH = _tabH;
    CGFloat bX = _edgeInset.left;
    CGFloat bY = _edgeInset.top;
    for (NSUInteger i = 0; i < _titleArray.count; i++) {
        CGFloat bW = [_titleArray[i] boundingRectWithSize:CGSizeMake(kTabViewW, _tabH)
                                                  options:NSStringDrawingUsesLineFragmentOrigin
                                               attributes:@{NSFontAttributeName : kTitleFont}
                                                  context:nil].size.width + kExtraW;
        if (bX + bW > kTabViewW) {
            bX = _edgeInset.left;
            bY = bY + _tabH + _marginV;
        }
        
        _maxH = bY+bH;
        
        bX = bX + bW + _marginH;
        
        if (bX > kTabViewW) {
            bX = _edgeInset.left;
            bY = bY+bH + _marginV;
        }
    }
    return _maxH + _edgeInset.bottom;
}

@end
