//
//  ViewController.m
//  多行标签
//
//  Created by 高立发 on 2016/12/22.
//  Copyright © 2016年 GG. All rights reserved.
//

#import "ViewController.h"
#import "LFTabView.h"

@interface ViewController () <LFTabViewDelegate>

//**  titleArray */
@property (nonatomic, strong) NSMutableArray *titleArray;

@end

@implementation ViewController

- (NSMutableArray *)titleArray
{
    if (!_titleArray) {
        _titleArray = [[NSMutableArray alloc]init];
        NSArray *titlesArr = @[@"是",@"叶孤城",@"西门吹雪",@"奥斯特洛夫斯基",@"849234721",@"鳌拜吗",@"q好滴",@"🙄",@"截取完几件大事的",@"Gucci",@"想叫你个巴拉"];
        [_titleArray addObjectsFromArray:titlesArr];
    }
    return _titleArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    LFTabView *tabView = [[LFTabView alloc]initWithTitleArray:self.titleArray
                                                  countPerRow:5
                                                      marginV:10
                                                      marginH:10
                                                  normalColor:nil
                                                selectedColor:nil
                                                         TabH:30
                                                    edgeInset:UIEdgeInsetsMake(10, 10, 10, 10)];
    
//    tabView.frame = CGRectMake(20, 80, kTabViewW, 300);
    
    // 提供了一个获取展示需求高度的方法: requiredH
    // 在view内部声明了一个创建view宽度的宏
    tabView.frame = CGRectMake(0, 80, kTabViewW, [tabView requiredH]);
    tabView.backgroundColor = [UIColor colorWithRed:243/255.0 green:243/255.0 blue:243/255.0 alpha:1.0];
//    tabView.delegate = self;
    tabView.tabClick = ^(NSArray *indexArr, NSArray *titlesArr) {
        NSLog(@"%@",titlesArr);
        NSLog(@"%@",indexArr);
    };
    [self.view addSubview:tabView];
}

#pragma mark =============== LFTabViewDelegate ===============
//- (void)didSelectATabAtIndex:(NSArray *)indexArr titleStr:(NSArray *)titlesArr
//{
//    NSLog(@"%@",titlesArr);
//    NSLog(@"%@",indexArr);
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

//    CGFloat kScreenW = [[UIScreen mainScreen]bounds].size.width;
//    NSUInteger buttonCount = 20;
//    NSUInteger countPerRow = 3;
//    UIEdgeInsets edgeInset = UIEdgeInsetsMake(20, 10, 20, 10);
//    CGFloat marginV = 10;
//    CGFloat marginH = 20;
//    CGFloat bW = (kScreenW - (countPerRow + 1) * marginH) / countPerRow;
//    CGFloat bH = 40;
//    CGFloat bgH = ((buttonCount - 1) / countPerRow + 1) * (bH + marginV);
//    UIView *lightgrayBG = [[UIView alloc]initWithFrame:CGRectMake(0, 40, kScreenW, bgH + 20)];
//    lightgrayBG.backgroundColor = [UIColor lightGrayColor];
//    [self.view addSubview:lightgrayBG];
//
//    for (NSUInteger i = 0; i < buttonCount; i++) {
//        CGFloat bX = marginH + i % countPerRow * (bW + marginH);
//        CGFloat bY = 20      + i / countPerRow * (bH + marginV);
//        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
//        btn.tag = 100+i;
//        btn.frame = CGRectMake(bX, bY, bW, bH);
//        [btn setTitle:[NSString stringWithFormat:@"I'm No.%lu",(unsigned long)i] forState:UIControlStateNormal];
//        [btn setBackgroundColor:[UIColor colorWithRed:arc4random_uniform(255.0)/255.0
//                                                green:arc4random_uniform(255.0)/255.0
//                                                 blue:arc4random_uniform(255.0)/255.0
//                                                alpha:1.0]];
//        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
//        [btn addTarget:self action:@selector(bClick:) forControlEvents:UIControlEventTouchUpInside];
//        [lightgrayBG addSubview:btn];
//    }

//- (void)bClick:(UIButton *)b
//{
//    NSLog(@"%@",b.titleLabel.text);
//}
