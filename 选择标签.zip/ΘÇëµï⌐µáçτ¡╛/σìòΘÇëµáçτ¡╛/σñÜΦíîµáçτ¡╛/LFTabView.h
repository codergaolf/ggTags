//
//  LFTabView.h
//  多行标签
//
//  Created by 高立发 on 2016/12/22.
//  Copyright © 2016年 GG. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol LFTabViewDelegate <NSObject>

@optional

- (void)didSelectATabAtIndex:(NSUInteger)index titleStr:(NSString *)title;

@end

@interface LFTabView : UIView

//**  每行个数, 默认: 3 */
@property (nonatomic, assign) NSUInteger countPerRow;

//**  垂直间距. 默认: 10 */
@property (nonatomic, assign) CGFloat marginV;

//**  水平间距, 默认: 10 */
@property (nonatomic, assign) CGFloat marginH;

//**  未选中颜色, 默认: 白色 */
@property (nonatomic, strong) UIColor *normalColor;

//**  选中颜色, 默认: 橘色 */
@property (nonatomic, strong) UIColor *selectedColor;

//**  标签高度, 默认: 40 */
@property (nonatomic, assign) CGFloat tabH;

//**  内部间距, 默认: (10, 10, 10, 10) */
@property (nonatomic) UIEdgeInsets edgeInset;

//**  提供了滚动的view */
@property (nonatomic, strong) UIScrollView *scrollView;

//**  传递事件的block */
@property (nonatomic, copy) void (^tabClick)(NSUInteger, NSString*);

//**  代理, 可以写也可以不写 */
@property (nonatomic, weak) id<LFTabViewDelegate> delegate;

// 创建view的构造方法
- (instancetype)initWithTitleArray:(NSArray *)titleArray
                       countPerRow:(NSUInteger)countPerRow
                           marginV:(CGFloat)marginV
                           marginH:(CGFloat)marginH
                       normalColor:(UIColor *)normalColor
                     selectedColor:(UIColor *)selectedColor
                              TabH:(CGFloat)tabH
                         edgeInset:(UIEdgeInsets)edgeInset;

// 提供了获取view高度的方法
- (CGFloat) requiredH;

@end
