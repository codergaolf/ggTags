//
//  main.m
//  多行标签
//
//  Created by 高立发 on 2016/12/22.
//  Copyright © 2016年 GG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
