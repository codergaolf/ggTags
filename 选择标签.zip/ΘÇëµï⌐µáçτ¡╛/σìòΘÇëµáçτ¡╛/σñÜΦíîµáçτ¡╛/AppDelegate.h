//
//  AppDelegate.h
//  多行标签
//
//  Created by 高立发 on 2016/12/22.
//  Copyright © 2016年 GG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

