//
//  LFTabView.m
//  多行标签
//
//  Created by 高立发 on 2016/12/22.
//  Copyright © 2016年 GG. All rights reserved.
//

#import "LFTabView.h"

@interface LFTabView()

//**  titleArray */
@property (nonatomic, strong) NSArray *titleArray;

//**  存放index值的数组 */
@property (nonatomic, strong) NSMutableArray *indexArr;
//**  存放标题的数组 */
@property (nonatomic, strong) NSMutableArray *titlesArr;

@end

@implementation LFTabView

#pragma mark - init
/// 创建view的构造方法
- (instancetype)initWithTitleArray:(NSArray *)titleArray
                       countPerRow:(NSUInteger)countPerRow
                           marginV:(CGFloat)marginV
                           marginH:(CGFloat)marginH
                       normalColor:(UIColor *)normalColor
                     selectedColor:(UIColor *)selectedColor
                              TabH:(CGFloat)tabH
                         edgeInset:(UIEdgeInsets)edgeInset
{
    self = [super init];
    if (!self) {
        return nil;
    }
    self.backgroundColor = [UIColor whiteColor];
    _titleArray    =  titleArray;
    _countPerRow   =  countPerRow   ?  countPerRow   :  3;
    _marginV       =  marginV       ?  marginV       :  10;
    _marginH       =  marginH       ?  marginH       :  10;
    _normalColor   =  normalColor   ?  normalColor   :  [UIColor whiteColor];
    _selectedColor =  selectedColor ?  selectedColor :  [UIColor orangeColor];
    _tabH          =  tabH          ?  tabH          :  40;
    _edgeInset     =  edgeInset;
    
    // 在获取到所有的属性之后, 设置scrollView的contentSize
    self.scrollView.contentSize = CGSizeMake(self.frame.size.width, [self requiredH]);
    
    return self;
}

#pragma mark - lazy
- (UIScrollView *)scrollView
{
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc]init];
        _scrollView.showsVerticalScrollIndicator = NO;
        _scrollView.showsHorizontalScrollIndicator = NO;
    }
    return _scrollView;
}

- (NSMutableArray *)titlesArr
{
    if (!_titlesArr) {
        _titlesArr = [[NSMutableArray alloc]init];
    }
    return _titlesArr;
}

- (NSMutableArray *)indexArr
{
    if (!_indexArr) {
        _indexArr = [[NSMutableArray alloc]init];
    }
    return _indexArr;
}

#pragma mark - set
- (void)setFrame:(CGRect)frame
{
    [super setFrame:frame];
    self.scrollView.frame = CGRectMake(0, 0, frame.size.width, frame.size.height);
    [self creatTab];
}

- (void)setBackgroundColor:(UIColor *)backgroundColor
{
    [super setBackgroundColor:backgroundColor];
    self.scrollView.backgroundColor = backgroundColor;
}

/**
      现在这所有的标签都是等宽的,没有考虑根据文字的多少自定义宽度
 */
- (void)creatTab
{
    CGFloat kViewW = self.frame.size.width;

    [self addSubview:self.scrollView];
    
    // 公式: (view宽度 - 中间的所有间距 - 左右间距) = 每行所有标签的总宽度 / 每行标签个数
    CGFloat bW = (kViewW - (_countPerRow - 1) * _marginH - _edgeInset.left - _edgeInset.right) / _countPerRow;
    CGFloat bH = _tabH;
    for (NSUInteger i = 0; i < _titleArray.count; i++) {
        CGFloat bX = _edgeInset.left + i % _countPerRow * (bW + _marginH);
        CGFloat bY = _edgeInset.top  + i / _countPerRow * (bH + _marginV);
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.tag = 100+i;
        btn.layer.cornerRadius = 3.0f;
        btn.clipsToBounds = YES;
        btn.layer.borderColor = [UIColor lightGrayColor].CGColor;
        btn.layer.borderWidth = 0.5f;
        btn.frame = CGRectMake(bX, bY, bW, bH);
        btn.selected = NO;
        [btn setTitle:_titleArray[i] forState:UIControlStateNormal];
        [btn setBackgroundColor:_normalColor];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(bClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.scrollView addSubview:btn];
    }
}

#pragma mark - Action
- (void)bClick:(UIButton *)currentB
{
    currentB.selected = !currentB.isSelected;
    
    __weak LFTabView *weakSelf = self;
    
    [currentB setBackgroundColor:currentB.isSelected ? _selectedColor : _normalColor];
    
    if (currentB.isSelected) {
        [self.indexArr addObject:@(currentB.tag - 100)];
        [self.titlesArr addObject:currentB.titleLabel.text];
    } else {
        [self.indexArr removeObject:@(currentB.tag - 100)];
        [self.titlesArr removeObject:currentB.titleLabel.text];
    }
    
    // block
    if (_tabClick) {
        _tabClick(weakSelf.indexArr, weakSelf.titlesArr);
    }
    
    // delegate
    if ([self.delegate respondsToSelector:@selector(didSelectATabAtIndex:titleStr:)]) {
        [self.delegate didSelectATabAtIndex:self.indexArr titleStr:self.titlesArr];
    }
}


// 返回一个创建这些标签所需的高度
- (CGFloat) requiredH
{
    return ((_titleArray.count- 1) / _countPerRow + 1) * (_tabH + _marginV) + _edgeInset.top + _edgeInset.bottom - _marginV;
}

@end
